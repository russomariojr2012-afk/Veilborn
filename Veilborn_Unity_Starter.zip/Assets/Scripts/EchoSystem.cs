using UnityEngine;

// Minimal Echo system for temporary buffs/abilities.
public class EchoSystem : MonoBehaviour
{
    public enum EchoType { Remorse, Rage, Mercy }
    public EchoType activeEcho = EchoType.Remorse;
    public float echoDuration = 10f;
    float timer = 0f;
    bool active = false;

    void Update()
    {
        if (active)
        {
            timer -= Time.deltaTime;
            if (timer <= 0f) { active = false; OnEchoEnd(); }
        }

        // test toggle (for prototype)
        if (Input.GetKeyDown(KeyCode.E))
        {
            ActivateEcho(activeEcho);
        }
    }

    public void ActivateEcho(EchoType type)
    {
        activeEcho = type;
        active = true;
        timer = echoDuration;
        OnEchoStart(type);
    }

    void OnEchoStart(EchoType type)
    {
        switch (type)
        {
            case EchoType.Remorse:
                // spawn shadow double (prototype placeholder)
                Debug.Log("Echo Remorse: spawn delayed double (prototype)");
                break;
            case EchoType.Rage:
                Debug.Log("Echo Rage: increased damage for duration");
                break;
            case EchoType.Mercy:
                Debug.Log("Echo Mercy: heal over time for duration");
                break;
        }
    }

    void OnEchoEnd()
    {
        Debug.Log("Echo ended");
    }
}
