using UnityEngine;

// Simple combat system: health, attack, parry.
public class CombatSystem : MonoBehaviour
{
    public float maxHealth = 100f;
    public float health;
    public float attackDamage = 20f;
    public float parryWindow = 0.25f; // seconds
    bool parryActive = false;

    void Start()
    {
        health = maxHealth;
    }

    public void Attack()
    {
        // simple attack: cast a short ray in front to hit enemies
        RaycastHit hit;
        Vector3 origin = transform.position + Vector3.up * 1.0f;
        Vector3 dir = transform.forward;
        float range = 2.2f;
        if (Physics.SphereCast(origin, 0.6f, dir, out hit, range))
        {
            CombatSystem enemy = hit.collider.GetComponent<CombatSystem>();
            if (enemy != null)
            {
                enemy.TakeDamage(attackDamage);
            }
        }
    }

    public void Parry()
    {
        if (!parryActive)
        {
            StartCoroutine(ParryWindow());
        }
    }

    System.Collections.IEnumerator ParryWindow()
    {
        parryActive = true;
        yield return new WaitForSeconds(parryWindow);
        parryActive = false;
    }

    public bool TryParry()
    {
        // Called by attacker to check if this unit parried
        if (parryActive)
        {
            // success
            parryActive = false;
            return true;
        }
        return false;
    }

    public void TakeDamage(float dmg)
    {
        health -= dmg;
        if (health <= 0f)
        {
            Die();
        }
    }

    void Die()
    {
        // placeholder death
        Debug.Log(gameObject.name + " died.");
        // In a full game: drop echoes, respawn logic, etc.
        gameObject.SetActive(false);
    }
}
