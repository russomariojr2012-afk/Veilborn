using UnityEngine;

// Basic player controller for a 3D prototype.
// Attach to the Player capsule. Requires a Rigidbody.
[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 4f;
    public float rotationSpeed = 10f;
    public float jumpForce = 5f;

    public float maxStamina = 100f;
    public float stamina;
    public float staminaRegenRate = 10f;
    public float dodgeCost = 20f;

    Rigidbody rb;
    Vector3 inputDir;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        stamina = maxStamina;
        rb.constraints = RigidbodyConstraints.FreezeRotation;
    }

    void Update()
    {
        // Input
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        inputDir = new Vector3(h, 0, v);
        if (inputDir.magnitude > 1f) inputDir.Normalize();

        // Rotation toward movement direction
        if (inputDir.sqrMagnitude > 0.01f)
        {
            Quaternion target = Quaternion.LookRotation(inputDir, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * rotationSpeed);
        }

        // Jump
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.VelocityChange);
        }

        // Dodge (roll)
        if (Input.GetKeyDown(KeyCode.LeftShift) && stamina >= dodgeCost)
        {
            StartCoroutine(Dodge());
        }

        // Stamina regen
        if (stamina < maxStamina)
        {
            stamina += staminaRegenRate * Time.deltaTime;
            if (stamina > maxStamina) stamina = maxStamina;
        }

        // Basic attack input (calls CombatSystem)
        if (Input.GetMouseButtonDown(0))
        {
            CombatSystem cs = GetComponent<CombatSystem>();
            if (cs != null) cs.Attack();
        }

        if (Input.GetMouseButtonDown(1))
        {
            CombatSystem cs = GetComponent<CombatSystem>();
            if (cs != null) cs.Parry();
        }
    }

    System.Collections.IEnumerator Dodge()
    {
        stamina -= dodgeCost;
        float dodgeDuration = 0.35f;
        float timer = 0f;
        Vector3 start = transform.position;
        Vector3 dir = transform.forward;
        float dodgeSpeed = 8f;

        while (timer < dodgeDuration)
        {
            rb.MovePosition(rb.position + dir * dodgeSpeed * Time.deltaTime);
            timer += Time.deltaTime;
            yield return null;
        }
    }

    bool IsGrounded()
    {
        RaycastHit hit;
        return Physics.Raycast(transform.position, Vector3.down, out hit, 1.1f);
    }
}
