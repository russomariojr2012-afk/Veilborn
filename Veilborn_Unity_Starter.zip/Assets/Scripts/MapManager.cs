using UnityEngine;
using UnityEngine.UI;

// Simple manager that displays map images and POI markers on a UI Canvas.
public class MapManager : MonoBehaviour
{
    public Image mapImage; // UI Image component to show the map sprite
    public Sprite[] mapSprites; // assign maps in inspector
    int currentMap = 0;

    void Start()
    {
        if (mapSprites != null && mapSprites.Length > 0 && mapImage != null)
        {
            mapImage.sprite = mapSprites[currentMap];
        }
    }

    // call this to switch map
    public void NextMap()
    {
        if (mapSprites == null || mapSprites.Length == 0) return;
        currentMap = (currentMap + 1) % mapSprites.Length;
        mapImage.sprite = mapSprites[currentMap];
    }
}
