using UnityEngine;
using System.Collections;

// Very simple enemy behaviour: patrol -> chase -> attack
[RequireComponent(typeof(CombatSystem))]
public class EnemyAI : MonoBehaviour
{
    public Transform[] patrolPoints;
    public float patrolSpeed = 2f;
    public float chaseSpeed = 3.5f;
    public float detectRadius = 8f;
    public float attackRange = 1.8f;
    int current = 0;
    Transform player;
    Rigidbody rb;
    CombatSystem combat;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        combat = GetComponent<CombatSystem>();
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
    }

    void Update()
    {
        if (player == null) return;

        float dist = Vector3.Distance(transform.position, player.position);
        if (dist < detectRadius)
        {
            // chase
            Vector3 dir = (player.position - transform.position).normalized;
            transform.position += dir * chaseSpeed * Time.deltaTime;
            transform.LookAt(new Vector3(player.position.x, transform.position.y, player.position.z));

            if (dist < attackRange)
            {
                // attack
                AttackPlayer();
            }
        }
        else
        {
            // patrol
            if (patrolPoints != null && patrolPoints.Length > 0)
            {
                Transform target = patrolPoints[current];
                Vector3 dir = (target.position - transform.position);
                if (dir.magnitude < 0.5f) { current = (current + 1) % patrolPoints.Length; }
                else
                {
                    transform.position += dir.normalized * patrolSpeed * Time.deltaTime;
                    transform.LookAt(new Vector3(target.position.x, transform.position.y, target.position.z));
                }
            }
        }
    }

    void AttackPlayer()
    {
        // Use CombatSystem to apply damage
        if (player == null) return;
        CombatSystem playerCombat = player.GetComponent<CombatSystem>();
        if (playerCombat == null) return;

        // Check if player parried
        if (playerCombat.TryParry())
        {
            // parry success: enemy staggered
            StartCoroutine(Stagger());
            return;
        }

        playerCombat.TakeDamage(combat.attackDamage);
    }

    IEnumerator Stagger()
    {
        float dur = 1.0f;
        float timer = 0f;
        while (timer < dur)
        {
            // simple stun
            timer += Time.deltaTime;
            yield return null;
        }
    }
}
