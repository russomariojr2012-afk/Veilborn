VEILBORN - Unity Starter Package
--------------------------------
Contenuto:
- Assets/Scripts/PlayerController.cs
- Assets/Scripts/CombatSystem.cs
- Assets/Scripts/EnemyAI.cs
- Assets/Scripts/EchoSystem.cs
- Assets/Scripts/MapManager.cs
- Assets/Maps/ (map images generated earlier)
- README_SETUP.txt

Scopo:
Questo pacchetto è un punto di partenza per sviluppare il prototipo action-RPG "Veilborn".
Contiene script C# pronti da importare in Unity (versione 2020.3+ raccomandata).
NON è un progetto Unity completo: include solo Assets utili (script, immagini, documentazione).

Istruzioni rapide:
1. Apri o crea un progetto Unity (2020.3 LTS o superiore raccomandato).
2. Copia la cartella 'Assets' dentro la root del tuo progetto Unity (rinomina se necessario).
3. In Unity, crea una scena nuova chiamata "Prototype".
4. Aggiungi un GameObject vuoto "GameManager" e assegna lo script MapManager (Assets/Scripts/MapManager.cs).
5. Crea un Player: GameObject -> 3D Object -> Capsule. Aggiungi Rigidbody (non kinematic), Capsule Collider.
   - Aggiungi lo script PlayerController.cs.
   - Aggiungi componenti richiesti: Animator (opzionale), AudioSource (opzionale).
6. Crea un prefab Enemy (es. Cube) e assegna EnemyAI.cs.
7. Leggi i commenti in ogni script per collegare vari riferimenti.

Contenuti principali (descrizione):
- PlayerController.cs: movimento base, gestione stamina, input per attacco e parry.
- CombatSystem.cs: script che gestisce salute, danno, parry timing, e ripristino.
- EnemyAI.cs: comportamento base: patrol, detect player, attacco melee.
- EchoSystem.cs: semplice implementazione degli "Echi del Velo" (abilità temporanee).
- MapManager.cs: carica e mostra le mappe (sprite) e tiene traccia dei punti di interesse.

Disclaimer:
- Questo è un prototipo di codice educativo. Alcune funzionalità (animazioni complesse, effetti VFX/SFX,
  navigazione avanzata, netcode, asset 3D/rigging) devono essere implementate da un team di sviluppo.
- Se vuoi, posso generare Blueprint/Blueprint-equivalenti per Unreal o GDScript per Godot.

Buon lavoro: con questo puoi subito testare il combat loop base e posizionare le mappe come reference.
